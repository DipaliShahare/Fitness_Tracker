import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Subject } from 'rxjs';
import { AuthData } from "./auth-data.model";
import { User } from "./user.model";

@Injectable()

export class AuthService {
  private user: User;
  authChange = new Subject<boolean>();

  constructor(private routes: Router){}

  registerUser(authData: AuthData){
    this.user = {
      email: authData.email,
      userID: Math.round(Math.random()*10000).toString()
    };
    this.authSuccessfully();
  }

  login(authData: AuthData){
    this.user = {
      email: authData.email,
      userID: Math.round(Math.random()*10000).toString()
    };
    this.authSuccessfully();
  }

  logout(){
    this.user = null;
    this.authChange.next(false);
  }

  getUser(){
    return {...this.user};
  }

  isAuth(){
    return this.user != null;
  }

  private authSuccessfully(){
    this.routes.navigate(['/training']);
    this.authChange.next(true);
  }
}
