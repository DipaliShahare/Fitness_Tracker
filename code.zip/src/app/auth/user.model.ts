export interface User {
  email: string;
  userID: string;
}
